DROP DATABASE IF EXISTS usal37;

CREATE DATABASE usal37 DEFAULT CHARACTER SET 'utf-8';

USE usal37;

CREATE TABLE Reparation
(
reparation_id INT PRIMARY KEY AUTO_INCREMENT,
reparation_date VARCHAR(32) NOT NULL,
reparation_time VARCHAR(32) NOT NULL,
reparation_duration DATETIME,
reparation_pretax_price INT
);

CREATE TABLE category
(
category_type
);

CREATE TABLE customers
(
customer_id INT PRIMARY KEY AUTO_INCREMENT,
customer_firstname VARCHAR(32) NOT NULL,
customer_lastname VARCHAR(32) NOT NULL,
customer_address VARCHAR(200)NOT NULL,
customer_phone CHAR(16) NOT NULL,
);

CREATE TABLE 
(
automechanic_code INT PRIMARY KEY AUTO_INCREMENT,
automechanic_name VARCHAR(100),
automechanic_password VARCHAR (255)
)
